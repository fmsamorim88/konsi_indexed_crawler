
const consumeCPFQueue = require('./message_broker');
(async() => await consumeCPFQueue())()
